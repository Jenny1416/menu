/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.jennymenus;

/**
 *
 * @author jenif
 */
public class JennyMenus {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
